import 'package:auren/features/finance/models/financial_place.dart';

class SampleFinancialData {
  // This would normally come from an API or local database
  static List<FinancialPlace> getNearbyFinancialPlaces(double userLat, double userLng) {
    print('Getting financial places near: $userLat, $userLng');
    // Calculate some places around the user's position
    return [
      // Banks - Using larger offsets to make them more visible on the map
      FinancialInstitution(
        id: 'bank1',
        name: 'Banco Auren',
        latitude: userLat + 0.002,
        longitude: userLng - 0.002,
        type: 'bank',
        institutionType: 'bank',
        services: ['checking', 'savings', 'investments', 'loans'],
        userAccountBalance: 2500.75,
        hasSavingsAccount: true,
      ),
      FinancialInstitution(
        id: 'bank2',
        name: 'Credit Union Local',
        latitude: userLat - 0.003,
        longitude: userLng + 0.003,
        type: 'bank',
        institutionType: 'credit_union',
        services: ['checking', 'savings', 'loans', 'mortgage'],
      ),
      FinancialInstitution(
        id: 'bank3',
        name: 'Banco Popular',
        latitude: userLat + 0.004,
        longitude: userLng + 0.004,
        type: 'bank',
        institutionType: 'bank',
        services: ['checking', 'savings', 'loans'],
      ),
      
      // ATMs - Using larger offsets to make them more visible on the map
      FinancialInstitution(
        id: 'atm1',
        name: 'ATM 24/7',
        latitude: userLat - 0.002,
        longitude: userLng - 0.003,
        type: 'atm',
        institutionType: 'atm',
        services: ['withdrawal', 'deposit', 'balance_check'],
      ),
      FinancialInstitution(
        id: 'atm2',
        name: 'Banco Auren ATM',
        latitude: userLat + 0.003,
        longitude: userLng - 0.001,
        type: 'atm',
        institutionType: 'atm',
        services: ['withdrawal', 'deposit', 'balance_check', 'bill_payment'],
        userAccountBalance: 2500.75,
      ),
      FinancialInstitution(
        id: 'atm3',
        name: 'ATM Shopping Center',
        latitude: userLat - 0.004,
        longitude: userLng + 0.002,
        type: 'atm',
        institutionType: 'atm',
        services: ['withdrawal', 'balance_check'],
      ),
      
      // Recent Expenses
      ExpensePlace(
        id: 'expense1',
        name: 'Café Gourmet',
        latitude: userLat + 0.001,
        longitude: userLng + 0.001,
        amount: 35.50,
        category: 'dining',
        date: DateTime.now().subtract(const Duration(days: 2)),
      ),
      ExpensePlace(
        id: 'expense2',
        name: 'Shopping Mall',
        latitude: userLat - 0.004,
        longitude: userLng - 0.002,
        amount: 450.75,
        category: 'shopping',
        date: DateTime.now().subtract(const Duration(days: 5)),
      ),
      ExpensePlace(
        id: 'expense3',
        name: 'Gas Station',
        latitude: userLat + 0.0025,
        longitude: userLng + 0.005,
        amount: 150.00,
        category: 'transportation',
        date: DateTime.now().subtract(const Duration(days: 1)),
      ),
      ExpensePlace(
        id: 'expense4',
        name: 'Monthly Gym',
        latitude: userLat - 0.001,
        longitude: userLng - 0.003,
        amount: 200.00,
        category: 'fitness',
        date: DateTime.now().subtract(const Duration(days: 10)),
        isRecurring: true,
      ),
    ];
  }
  
  static List<BudgetAlert> getBudgetAlerts() {
    return [
      BudgetAlert(
        category: 'dining',
        budgetLimit: 500.0,
        currentSpending: 450.0,
        latitude: -23.5558,
        longitude: -46.6396, // São Paulo
        radius: 1000.0,
      ),
      BudgetAlert(
        category: 'entertainment',
        budgetLimit: 300.0,
        currentSpending: 320.0,
        latitude: -22.9068,
        longitude: -43.1729, // Rio de Janeiro
        radius: 800.0,
      ),
      BudgetAlert(
        category: 'shopping',
        budgetLimit: 1000.0,
        currentSpending: 750.0,
        latitude: -15.7801,
        longitude: -47.9292, // Brasília
        radius: 1200.0,
      ),
    ];
  }
  
  static Map<String, double> getMonthlyExpensesByCategory() {
    return {
      'dining': 450.0,
      'transportation': 350.0,
      'shopping': 750.0,
      'entertainment': 320.0,
      'fitness': 200.0,
      'utilities': 550.0,
      'rent': 1500.0,
    };
  }
}
