import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import '../models/financial_place.dart';
import 'dart:math' as math;

class FinancialMapUtils {
  // Calculate distance between two points using Haversine formula
  static double calculateDistance(
    double lat1, double lon1, double lat2, double lon2) {
    const R = 6371000; // Earth radius in meters
    
    final phi1 = lat1 * math.pi / 180;
    final phi2 = lat2 * math.pi / 180;
    final deltaPhi = (lat2 - lat1) * math.pi / 180;
    final deltaLambda = (lon2 - lon1) * math.pi / 180;
    
    final a = math.sin(deltaPhi / 2) * math.sin(deltaPhi / 2) +
        math.cos(phi1) * math.cos(phi2) *
        math.sin(deltaLambda / 2) * math.sin(deltaLambda / 2);
    final c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a));
    final distance = R * c;
    
    return distance;
  }
  
  // Get appropriate icon for marker type
  static BitmapDescriptor getMarkerIcon(String type) {
    switch (type) {
      case 'bank':
        return BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueGreen);
      case 'atm':
        return BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueYellow);
      case 'expense':
        return BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueRed);
      default:
        return BitmapDescriptor.defaultMarker;
    }
  }
  
  // Get color for expense category 
  static Color getExpenseCategoryColor(String category) {
    switch (category.toLowerCase()) {
      case 'dining':
        return Colors.orange;
      case 'transportation':
        return Colors.blue;
      case 'shopping':
        return Colors.purple;
      case 'entertainment':
        return Colors.pink;
      case 'fitness':
        return Colors.teal;
      case 'utilities':
        return Colors.brown;
      case 'rent':
        return Colors.indigo;
      default:
        return Colors.grey;
    }
  }
  
  // Format currency (Brazilian Real)
  static String formatCurrency(double amount) {
    return 'R\$ ${amount.toStringAsFixed(2).replaceAll('.', ',')}';
  }
  
  // Get marker snippet text based on place type
  static String getMarkerSnippet(FinancialPlace place) {
    if (place is ExpensePlace) {
      return 'R\$ ${place.amount.toStringAsFixed(2)} • ${place.category} • ${_formatDate(place.date)}';
    } else if (place is FinancialInstitution) {
      if (place.userAccountBalance != null) {
        return 'Saldo: R\$ ${place.userAccountBalance?.toStringAsFixed(2)} • ${place.services.join(", ")}';
      } else {
        return place.services.join(", ");
      }
    }
    return '';
  }
  
  // Simple date formatter
  static String _formatDate(DateTime date) {
    return '${date.day}/${date.month}/${date.year}';
  }
}
