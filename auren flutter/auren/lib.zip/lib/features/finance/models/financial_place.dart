class FinancialPlace {
  final String id;
  final String name;
  final double latitude;
  final double longitude;
  final String type; // 'bank', 'atm', 'expense'
  final String? icon;
  final Map<String, dynamic>? details;

  const FinancialPlace({
    required this.id,
    required this.name,
    required this.latitude,
    required this.longitude,
    required this.type,
    this.icon,
    this.details,
  });
}

class ExpensePlace extends FinancialPlace {
  final double amount;
  final String category;
  final DateTime date;
  final bool isRecurring;

  ExpensePlace({
    required super.id,
    required super.name,
    required super.latitude,
    required super.longitude,
    required this.amount,
    required this.category,
    required this.date,
    this.isRecurring = false,
  }) : super(
          type: 'expense',
          details: {
            'amount': amount,
            'category': category,
            'date': date.toIso8601String(),
            'isRecurring': isRecurring,
          },
        );
}

class FinancialInstitution extends FinancialPlace {
  final String institutionType; // 'bank', 'credit_union', 'investment_firm'
  final List<String> services;
  final double? userAccountBalance;
  final bool hasSavingsAccount;

  FinancialInstitution({
    required super.id,
    required super.name,
    required super.latitude,
    required super.longitude,
    required super.type,
    required this.institutionType,
    this.services = const [],
    this.userAccountBalance,
    this.hasSavingsAccount = false,
  }) : super(
          details: {
            'institutionType': institutionType,
            'services': services,
            'userAccountBalance': userAccountBalance,
            'hasSavingsAccount': hasSavingsAccount,
          },
        );
}

class BudgetAlert {
  final String category;
  final double budgetLimit;
  final double currentSpending;
  final double latitude;
  final double longitude;
  final double radius; // radius in meters defining the alert zone

  const BudgetAlert({
    required this.category,
    required this.budgetLimit,
    required this.currentSpending,
    required this.latitude,
    required this.longitude,
    this.radius = 500.0,
  });

  bool get isOverBudget => currentSpending >= budgetLimit;
  double get percentUsed => (currentSpending / budgetLimit) * 100;
}
