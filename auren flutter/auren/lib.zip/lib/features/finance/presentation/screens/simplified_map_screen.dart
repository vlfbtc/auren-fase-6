import 'dart:async';
import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:geolocator/geolocator.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:auren/features/finance/models/financial_place.dart';
import 'package:auren/features/finance/data/sample_financial_data.dart';
import 'package:auren/features/finance/utils/financial_map_utils.dart';

class SimplifiedMapScreen extends StatefulWidget {
  final bool showAppBar;
  
  const SimplifiedMapScreen({super.key, this.showAppBar = true});

  @override
  State<SimplifiedMapScreen> createState() => _SimplifiedMapScreenState();
}

class _SimplifiedMapScreenState extends State<SimplifiedMapScreen> {
  // Map style that hides all POIs
  // Enhanced map style that hides POIs but keeps essential UI elements
  static const String _mapStyle = '''
  [
    {
      "featureType": "poi",
      "elementType": "all",
      "stylers": [
        { "visibility": "off" }
      ]
    },
    {
      "featureType": "poi.business",
      "stylers": [
        { "visibility": "off" }
      ]
    },
    {
      "featureType": "poi.park",
      "elementType": "labels.text",
      "stylers": [
        { "visibility": "off" }
      ]
    },
    {
      "featureType": "road",
      "elementType": "labels",
      "stylers": [
        { "visibility": "on" }
      ]
    },
    {
      "featureType": "landscape",
      "elementType": "all",
      "stylers": [
        { "visibility": "on" }
      ]
    }
  ]
  ''';

  final Completer<GoogleMapController> _controller = Completer();
  final Map<MarkerId, Marker> _markers = {};
  final Map<MarkerId, Marker> _allMarkers = {}; // Store all markers before filtering
  
  CameraPosition? _initialPosition;
  bool _isLoading = true;
  
  // Financial data
  List<FinancialPlace> _financialPlaces = [];
  
  // Filter state variables - simplified to just banks and ATMs
  bool _showBanks = true;
  bool _showATMs = true;

  @override
  void initState() {
    super.initState();
    // Request location permission when the screen is initialized
    _requestLocationPermission();
  }

  // Implementation of permission request method
  Future<void> _requestLocationPermission() async {
    final status = await Permission.location.request();
    
    if (status.isGranted) {
      // Permission granted, we can get location
      _getCurrentLocation();
    } else if (status.isDenied) {
      // Permission denied, show message to user
      setState(() {
        _isLoading = false;
        _initialPosition = const CameraPosition(
          target: LatLng(-15.7801, -47.9292), // Default position (Brasília)
          zoom: 14.0,
        );
      });
      _showPermissionDeniedDialog();
    } else if (status.isPermanentlyDenied) {
      // Permission permanently denied, take user to settings
      setState(() {
        _isLoading = false;
        _initialPosition = const CameraPosition(
          target: LatLng(-15.7801, -47.9292), // Default position (Brasília)
          zoom: 14.0,
        );
      });
      _showOpenSettingsDialog();
    }
  }

  // Method to get current location using Geolocator
  Future<void> _getCurrentLocation() async {
    try {
      final position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
      );
      
      setState(() {
        _initialPosition = CameraPosition(
          target: LatLng(position.latitude, position.longitude),
          zoom: 14.0,
        );
        _isLoading = false;
      });
      
      // Add marker at user location
      _addUserMarker(position);
      
      // Fetch and add financial locations nearby
      _loadFinancialData(position);
      
    } catch (e) {
      print('Error getting location: $e');
      setState(() {
        _isLoading = false;
        _initialPosition = const CameraPosition(
          target: LatLng(-15.7801, -47.9292), // Default position (Brasília)
          zoom: 14.0,
        );
      });
    }
  }

  void _addUserMarker(Position position) {
    final markerId = const MarkerId('user_location');
    final marker = Marker(
      markerId: markerId,
      position: LatLng(position.latitude, position.longitude),
      infoWindow: const InfoWindow(title: 'Sua localização'),
      icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueAzure),
      zIndex: 1,
    );
    
    setState(() {
      _markers[markerId] = marker;
      _allMarkers[markerId] = marker; // Save to all markers too
      
      // Add test bank and ATM markers to verify they can be displayed
      _addTestMarkers(position);
    });
  }
  
  // Add test markers to verify visibility
  void _addTestMarkers(Position position) {
    print('Adding test markers around user position');
    
    // Test Bank marker
    final bankMarkerId = const MarkerId('bank_test');
    final bankMarker = Marker(
      markerId: bankMarkerId,
      position: LatLng(position.latitude + 0.001, position.longitude + 0.001),
      infoWindow: const InfoWindow(
        title: 'Banco Teste',
        snippet: 'Este é um marcador de teste para banco',
      ),
      icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueGreen),
      zIndex: 2,
    );
    
    // Test ATM marker
    final atmMarkerId = const MarkerId('atm_test');
    final atmMarker = Marker(
      markerId: atmMarkerId,
      position: LatLng(position.latitude - 0.001, position.longitude - 0.001),
      infoWindow: const InfoWindow(
        title: 'Caixa Eletrônico Teste',
        snippet: 'Este é um marcador de teste para ATM',
      ),
      icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueYellow),
      zIndex: 2,
    );
    
    _markers[bankMarkerId] = bankMarker;
    _allMarkers[bankMarkerId] = bankMarker;
    
    _markers[atmMarkerId] = atmMarker;
    _allMarkers[atmMarkerId] = atmMarker;
    
    print('Added test markers. Total markers: ${_markers.length}');
  }
  
  // Load financial data around the user's position - simplified to only handle banks and ATMs
  void _loadFinancialData(Position position) {
    // Get nearby financial places from sample data
    _financialPlaces = SampleFinancialData.getNearbyFinancialPlaces(
      position.latitude, position.longitude);
    
    print('Loaded ${_financialPlaces.length} financial places from data source');
    
    // Add ALL financial places to check what we're receiving
    for (var place in _financialPlaces) {
      print('Processing place: ${place.name}, type: ${place.type}, class: ${place.runtimeType}');
      
      // Add banks and ATMs as markers
      if ((place.type == 'bank' || place.type == 'atm')) {
        print('Adding financial place: ${place.name}, type: ${place.type}');
        _addFinancialPlaceMarker(place);
      } else {
        print('Skipping non-bank/ATM place: ${place.name}, type: ${place.type}');
      }
    }
    
    // Print debug information
    print('Total markers added: ${_allMarkers.length}');
    
    // Apply the initial filters
    _applyFilters();
    
    // Print debug information about markers
    _printMarkerDebugInfo();
    
    if (_allMarkers.isEmpty || _allMarkers.length <= 1) {
      print('WARNING: No financial institution markers were created!');
    }
  }
  
  void _addFinancialPlaceMarker(FinancialPlace place) {
    // Ensure we only add banks and ATMs
    if (!(place.type == 'bank' || place.type == 'atm')) {
      print('Skipping non-financial marker: ${place.name}, type: ${place.type}');
      return;
    }
    
    final markerId = MarkerId('${place.type}_${place.id}');
    print('Creating marker with ID: ${markerId.value}');
    
    // Create a more visible custom icon based on place type
    BitmapDescriptor icon;
    switch(place.type) {
      case 'bank':
        icon = BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueGreen);
        break;
      case 'atm':
        icon = BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueYellow);
        break;
      default:
        icon = BitmapDescriptor.defaultMarker;
    }
    
    // Create descriptive snippet
    String snippet;
    if (place is FinancialInstitution) {
      snippet = "Tipo: ${_formatInstitutionType(place.institutionType)}";
      if (place.services.isNotEmpty) {
        snippet += "\nServiços: ${place.services.take(2).join(', ')}${place.services.length > 2 ? '...' : ''}";
      }
    } else {
      snippet = "Local financeiro";
    }
    
    final marker = Marker(
      markerId: markerId,
      position: LatLng(place.latitude, place.longitude),
      infoWindow: InfoWindow(
        title: place.name,
        snippet: snippet,
      ),
      icon: icon,
      onTap: () {
        if (place is FinancialInstitution) {
          _showInstitutionDetails(place);
        }
      },
      // Make marker more visible
      alpha: 1.0,
      zIndex: 2,
      visible: true,
    );
    
    print('Adding marker: ${place.name} at position ${place.latitude},${place.longitude}');
    
    setState(() {
      _markers[markerId] = marker;
      _allMarkers[markerId] = marker;
      print('Added marker to collections. Total markers: ${_allMarkers.length}');
    });
  }
  
  // Show detailed information about financial institution
  void _showInstitutionDetails(FinancialInstitution institution) {
    showModalBottomSheet(
      context: context,
      builder: (context) => Container(
        padding: const EdgeInsets.all(16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              institution.name,
              style: const TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              _formatInstitutionType(institution.institutionType),
              style: const TextStyle(
                fontSize: 16,
                color: Colors.grey,
              ),
            ),
            const Divider(height: 24),
            if (institution.userAccountBalance != null)
              _infoRow('Saldo na Conta', FinancialMapUtils.formatCurrency(institution.userAccountBalance!)),
            _infoRow('Serviços Disponíveis', _formatServices(institution.services)),
            
            if (institution.institutionType == 'bank') ...[
              const SizedBox(height: 16),
              Row(
                children: [
                  Expanded(
                    child: ElevatedButton.icon(
                      onPressed: () {
                        // Would navigate to account details
                        Navigator.pop(context);
                      },
                      icon: const Icon(Icons.account_balance),
                      label: const Text('Ver Conta'),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Theme.of(context).primaryColor,
                      ),
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: () {
                        // Would navigate to services
                        Navigator.pop(context);
                      },
                      icon: const Icon(Icons.payment),
                      label: const Text('Serviços'),
                    ),
                  ),
                ],
              ),
            ],
          ],
        ),
      ),
    );
  }
  
  // Apply filters to markers based on type (simplified to just banks and ATMs)
  void _applyFilters() {
    // Add debug information
    print('Applying filters - Banks: $_showBanks, ATMs: $_showATMs');
    print('All markers before filtering: ${_allMarkers.length}');
    
    setState(() {
      _markers.clear(); // Clear all current markers
      
      // Always show user location marker
      final userMarkerId = const MarkerId('user_location');
      if (_allMarkers.containsKey(userMarkerId)) {
        _markers[userMarkerId] = _allMarkers[userMarkerId]!;
      }
      
      // Filter and add other markers based on their type
      _allMarkers.forEach((id, marker) {
        if (id.value != 'user_location') {
          final idParts = id.value.split('_');
          if (idParts.isEmpty) return;
          
          String markerType = idParts[0];
          print('Checking marker: ${id.value}, type: $markerType');
          
          // Check if this marker type should be shown based on filter settings
          bool shouldShow = false;
          
          if (markerType == 'bank' && _showBanks) {
            print('Adding bank marker: ${id.value}');
            shouldShow = true;
          } else if (markerType == 'atm' && _showATMs) {
            print('Adding ATM marker: ${id.value}');
            shouldShow = true;
          }
          
          // Add marker if it passed all filter checks
          if (shouldShow) {
            _markers[id] = marker;
          }
        }
      });
      
      print('Markers after filtering: ${_markers.length}');
    });
  }

  // Show filter dialog with simplified options
  void _showFilterDialog() {
    // Create temporary variables to hold the filter state during dialog editing
    bool showBanks = _showBanks;
    bool showATMs = _showATMs;

    showDialog(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          title: const Text('Filtrar Mapa Financeiro'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              _buildFilterOption('Bancos', Icons.account_balance, showBanks, 
                (value) => setDialogState(() => showBanks = value!)),
              _buildFilterOption('Caixas Eletrônicos', Icons.atm, showATMs, 
                (value) => setDialogState(() => showATMs = value!)),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(ctx).pop(),
              child: const Text('Cancelar'),
            ),
            TextButton(
              onPressed: () {
                // Keep track of our filter selection
                print('Filter dialog apply: Banks: $showBanks, ATMs: $showATMs');
                
                // Close dialog first
                Navigator.of(ctx).pop();
                
                // Update the real filter state and apply filters
                setState(() {
                  _showBanks = showBanks;
                  _showATMs = showATMs;
                  
                  print('State updated: _showBanks: $_showBanks, _showATMs: $_showATMs');
                  
                  // Directly clear and update markers here for immediate effect
                  _markers.clear();
                  
                  // Always add user location
                  final userMarkerId = const MarkerId('user_location');
                  if (_allMarkers.containsKey(userMarkerId)) {
                    _markers[userMarkerId] = _allMarkers[userMarkerId]!;
                  }
                  
                  // Filter based on selected types
                  for (final entry in _allMarkers.entries) {
                    final id = entry.key;
                    if (id.value != 'user_location' && 
                        ((id.value.startsWith('bank') && showBanks) || 
                         (id.value.startsWith('atm') && showATMs))) {
                      _markers[id] = entry.value;
                      print('Added marker: ${id.value}');
                    }
                  }
                });
                
                // Apply the filter to markers after state update
                _applyFilters();
                
                // Print debug information about markers
                _printMarkerDebugInfo();
              },
              child: const Text('Aplicar'),
            ),
          ],
        ),
      ),
    );
  }

  // Dialog for denied permission
  void _showPermissionDeniedDialog() {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Permissão de Localização Negada'),
        content: const Text(
          'Não foi possível obter sua localização atual. O mapa mostrará uma posição padrão. Para melhor experiência, conceda a permissão de localização.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(),
            child: const Text('OK'),
          ),
          TextButton(
            onPressed: _requestLocationPermission,
            child: const Text('Tentar Novamente'),
          ),
        ],
      ),
    );
  }

  // Dialog to take to settings when permission is permanently denied
  void _showOpenSettingsDialog() {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Permissão de Localização Negada'),
        content: const Text(
          'A permissão de localização foi negada permanentemente. Para usar todos os recursos do mapa, por favor vá às configurações do aplicativo e habilite a permissão de localização.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(),
            child: const Text('Cancelar'),
          ),
          TextButton(
            onPressed: () async {
              Navigator.of(ctx).pop();
              await openAppSettings();
            },
            child: const Text('Abrir Configurações'),
          ),
        ],
      ),
    );
  }

  // Debug method to print all markers
  void _printMarkerDebugInfo() {
    print('===== MARKER DEBUG INFO =====');
    print('Total markers in _allMarkers: ${_allMarkers.length}');
    print('Total markers in _markers: ${_markers.length}');
    
    print('\nAll markers:');
    _allMarkers.forEach((id, marker) {
      print('  - ${id.value}');
    });
    
    print('\nFiltered markers:');
    _markers.forEach((id, marker) {
      print('  - ${id.value}');
    });
    print('============================');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: widget.showAppBar ? AppBar(
        title: const Text('Mapa Financeiro'),
        backgroundColor: Theme.of(context).primaryColor,
      ) : null,
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : Stack(
              children: [
                GoogleMap(
                  mapType: MapType.normal,
                  initialCameraPosition: _initialPosition!,
                  onMapCreated: (GoogleMapController controller) async {
                    _controller.complete(controller);
                    
                    // Apply custom style to hide Google's POIs
                    print('Setting map style to hide POIs');
                    await controller.setMapStyle(_mapStyle);
                    print('Map style applied successfully');
                    
                    // Print debug info when map is created
                    print('Map created. Current markers: ${_markers.length}');
                    _printMarkerDebugInfo();
                    
                    // Force refresh markers after a short delay
                    Future.delayed(const Duration(milliseconds: 500), () {
                      if (mounted) {
                        setState(() {
                          // This will force the map to refresh its markers
                          print('Refreshing markers display');
                        });
                      }
                    });
                  },
                  markers: Set<Marker>.of(_markers.values),
                  myLocationEnabled: true,
                  myLocationButtonEnabled: true,
                  compassEnabled: true,
                  trafficEnabled: false,
                  indoorViewEnabled: false,
                  // Ensure these settings don't hide our own markers
                  buildingsEnabled: true,
                  tiltGesturesEnabled: false,
                  zoomControlsEnabled: true,
                  mapToolbarEnabled: true,
                ),
                Positioned(
                  bottom: 100,
                  right: 16,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      FloatingActionButton(
                        heroTag: 'refresh',
                        backgroundColor: Colors.blue,
                        child: const Icon(Icons.refresh),
                        onPressed: () {
                          // Reload the current position and financial data
                          print('Refreshing map data');
                          _getCurrentLocation();
                        },
                      ),
                      const SizedBox(height: 16),
                      FloatingActionButton(
                        heroTag: 'filter',
                        backgroundColor: Theme.of(context).primaryColor,
                        child: const Icon(Icons.filter_alt),
                        onPressed: _showFilterDialog,
                      ),
                    ],
                  ),
                ),
                // Enhanced legend with status
                Positioned(
                  top: 10,
                  left: 10,
                  child: Card(
                    elevation: 4,
                    color: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                      side: BorderSide(color: Theme.of(context).primaryColor, width: 1),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(12.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Row(
                            children: [
                              Icon(Icons.info_outline, color: Theme.of(context).primaryColor, size: 18),
                              const SizedBox(width: 4),
                              const Text('Legenda do Mapa', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                            ],
                          ),
                          const Divider(),
                          Row(
                            children: [
                              Icon(Icons.account_balance, color: Colors.green, size: 20),
                              const SizedBox(width: 8),
                              const Text('Bancos', style: TextStyle(fontSize: 14)),
                              const SizedBox(width: 4),
                              Text('(${_showBanks ? "Visíveis" : "Ocultos"})', 
                                style: TextStyle(
                                  fontSize: 12, 
                                  fontStyle: FontStyle.italic,
                                  color: _showBanks ? Colors.green : Colors.red,
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 8),
                          Row(
                            children: [
                              Icon(Icons.atm, color: Colors.amber, size: 20),
                              const SizedBox(width: 8),
                              const Text('Caixas Eletrônicos', style: TextStyle(fontSize: 14)),
                              const SizedBox(width: 4),
                              Text('(${_showATMs ? "Visíveis" : "Ocultos"})', 
                                style: TextStyle(
                                  fontSize: 12, 
                                  fontStyle: FontStyle.italic,
                                  color: _showATMs ? Colors.green : Colors.red,
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 8),
                          Text(
                            'Total exibido: ${_markers.length - 1} locais', // -1 for user location
                            style: const TextStyle(fontSize: 12, fontStyle: FontStyle.italic),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
    );
  }

  Widget _buildFilterOption(String title, IconData icon, bool isChecked, Function(bool?) onChanged) {
    return CheckboxListTile(
      title: Text(title),
      secondary: Icon(
        icon,
        color: title == 'Bancos' 
            ? Colors.green 
            : (title == 'Caixas Eletrônicos' ? Colors.amber : Colors.grey),
        size: 28,
      ),
      activeColor: Theme.of(context).primaryColor,
      value: isChecked,
      onChanged: onChanged,
      dense: true,
    );
  }
  
  Widget _infoRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: const TextStyle(color: Colors.grey),
          ),
          Text(
            value,
            style: const TextStyle(fontWeight: FontWeight.bold),
          ),
        ],
      ),
    );
  }
  
  // Format institution type to user-friendly string
  String _formatInstitutionType(String type) {
    switch (type) {
      case 'bank':
        return 'Banco';
      case 'credit_union':
        return 'Cooperativa de Crédito';
      case 'investment_firm':
        return 'Corretora de Investimentos';
      case 'atm':
        return 'Caixa Eletrônico';
      default:
        return type;
    }
  }
  
  // Format services list to user-friendly string
  String _formatServices(List<String> services) {
    final serviceNames = services.map((service) {
      switch (service) {
        case 'checking':
          return 'Conta Corrente';
        case 'savings':
          return 'Poupança';
        case 'investments':
          return 'Investimentos';
        case 'loans':
          return 'Empréstimos';
        case 'mortgage':
          return 'Financiamento';
        case 'withdrawal':
          return 'Saque';
        case 'deposit':
          return 'Depósito';
        case 'balance_check':
          return 'Consulta de Saldo';
        case 'bill_payment':
          return 'Pagamento de Contas';
        default:
          return service;
      }
    }).toList();
    
    return serviceNames.join(', ');
  }
}
