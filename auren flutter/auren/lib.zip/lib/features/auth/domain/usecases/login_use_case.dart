import '../../data/repositories/auth_repository.dart';
import '../../../../core/token_storage.dart';

class LoginUseCase {
  final AuthRepository repository;
  LoginUseCase(this.repository);

  /// Keep returning String if other layers expect it:
  Future<String> call({required String email, required String password}) async {
    await repository.login(email: email, password: password);
    final stored = await TokenStorage.read();
    return stored?.accessToken ?? '';
  }
}
