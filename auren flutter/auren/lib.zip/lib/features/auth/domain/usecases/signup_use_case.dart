import 'package:auren/features/auth/data/repositories/auth_repository.dart';

class SignupUseCase {
  final AuthRepository repo;
  SignupUseCase({required this.repo});

  Future<Map<String, dynamic>> call({
    required String email,
    required String firstName,
    required String lastName,
    required DateTime birthDate,
  }) {
    return repo.signupStart(
      email: email,
      firstName: firstName,
      lastName: lastName,
      birthDate: birthDate,
    );
  }
}
