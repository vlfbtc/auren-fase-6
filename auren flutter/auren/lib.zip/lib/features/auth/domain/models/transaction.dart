// lib/features/auth/domain/models/transaction.dart
import 'dart:convert';

enum TransactionType { income, expense }

TransactionType _typeFromString(String? s) {
  if (s == null) return TransactionType.expense;
  return s.toUpperCase() == 'INCOME' ? TransactionType.income : TransactionType.expense;
}

String _typeToString(TransactionType t) => t == TransactionType.income ? 'INCOME' : 'EXPENSE';

class Transaction {
  final int? id;
  final double amount; // Valor como veio/foi digitado (positivo)
  final String description;
  final String category;
  final DateTime date;
  final TransactionType type;

  const Transaction({
    this.id,
    required this.amount,
    required this.description,
    required this.category,
    required this.date,
    required this.type,
  });

  bool get isExpense => type == TransactionType.expense;

  /// Backend -> App
  factory Transaction.fromJson(Map<String, dynamic> json) {
    final t = _typeFromString(json['type'] as String?);
    final rawAmount = (json['amount'] as num).toDouble();
    // Mantemos o valor conforme a API; para gráficos/usos internos, use .abs() quando for despesa negativa
    return Transaction(
      id: json['id'] is int ? json['id'] as int : (json['id'] == null ? null : int.tryParse(json['id'].toString())),
      amount: rawAmount,
      description: json['description'] as String? ?? '',
      category: json['category'] as String? ?? 'Outros',
      date: DateTime.parse(json['date'] as String),
      type: t,
    );
  }

  /// App -> Backend (criação/atualização)
  Map<String, dynamic> toCreateJson() {
    return {
      'description': description,
      'amount': amount, // enviamos positivo; quem define saída é 'type'
      'category': category,
      'date': date.toIso8601String(),
      'type': _typeToString(type),
    };
  }

  static List<Transaction> listFromJson(String body) {
    final decoded = jsonDecode(body);
    if (decoded is List) {
      return decoded.map((e) => Transaction.fromJson(e as Map<String, dynamic>)).toList();
    }
    return const [];
  }
}
