/// Classe de sessão para manter dados globais do usuário autenticado
class Session {
  static String? authToken;
  static String? userName;
// Poderíamos armazenar também userId, email etc., se necessário.
}
