import '../models/transaction.dart' as my_models;

// Mock implementation of Firestore service that doesn't use Firebase
class FirestoreService {
  // Simulated in-memory database
  final Map<String, List<my_models.Transaction>> _userTransactions = {};
  final Map<String, Map<String, dynamic>> _userPreferences = {};
      
  // Method to save a transaction 
  Future<void> addTransaction(String userId, my_models.Transaction transaction) async {
    try {
      // Initialize user transactions list if it doesn't exist
      if (!_userTransactions.containsKey(userId)) {
        _userTransactions[userId] = [];
      }
      
      // Add transaction to in-memory storage
      _userTransactions[userId]!.add(transaction);
      print('Transaction added to local storage for user: $userId');
    } catch (e) {
      print('Error saving transaction: $e');
      rethrow;
    }
  }
  
  // Method to get user transactions as a stream
  Stream<List<my_models.Transaction>> getUserTransactions(String userId) {
    // Return empty list if user has no transactions
    if (!_userTransactions.containsKey(userId)) {
      return Stream.value([]);
    }
    
    // Return transactions from in-memory storage
    return Stream.value(_userTransactions[userId]!);
  }
  
  // Method to save user preferences
  Future<void> saveUserPreferences(String userId, Map<String, dynamic> preferences) async {
    try {
      _userPreferences[userId] = preferences;
      print('User preferences saved for user: $userId');
    } catch (e) {
      print('Error saving user preferences: $e');
      rethrow;
    }
  }
  
  // Method to get user preferences
  Future<Map<String, dynamic>> getUserPreferences(String userId) async {
    return _userPreferences[userId] ?? {};
  }
  
  // Method to update user profile data
  Future<void> updateUserProfile(String userId, Map<String, dynamic> profileData) async {
    try {
      // In a real implementation, this would update the user document in Firestore
      print('User profile updated for user: $userId');
    } catch (e) {
      print('Error updating user profile: $e');
      rethrow;
    }
  }
}
