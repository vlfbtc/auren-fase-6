import 'package:flutter/material.dart';
import 'package:auren/features/auth/data/datasources/insights_api_service.dart';

class InsightsScreen extends StatefulWidget {
  final bool showAppBar;
  const InsightsScreen({super.key, this.showAppBar = true});

  @override
  State<InsightsScreen> createState() => _InsightsScreenState();
}

class _InsightsScreenState extends State<InsightsScreen> {
  final InsightsApiService _service = InsightsApiService();

  List<FinancialTip> _financialTips = [];
  List<EducationalContentItem> _educationalContent = [];

  @override
  void initState() {
    super.initState();
    _loadFinancialContent();
  }

  Future<void> _loadFinancialContent() async {
    try {
      // 1) Gera/atualiza insights no backend
      await _service.generate(topN: 10);
      // 2) Busca o snapshot mais recente
      final bundle = await _service.recent();

      if (!mounted) return;
      setState(() {
        _financialTips = bundle.tips;
        _educationalContent = bundle.content;
      });
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Erro ao carregar conteúdo educacional: $e'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: widget.showAppBar
          ? AppBar(
        backgroundColor: Theme.of(context).primaryColor,
        title: const Text('Auren', style: TextStyle(color: Colors.white)),
        elevation: 0,
      )
          : null,
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Center(
                child: Text(
                  'Auren',
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.w500,
                    color: Colors.grey,
                  ),
                ),
              ),
              const SizedBox(height: 24),

              // Recomendações Personalizadas
              Text(
                'Recomendações Personalizadas',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: Colors.grey[800],
                ),
              ),
              const SizedBox(height: 8),
              const Divider(thickness: 1.0),
              const SizedBox(height: 8),

              _financialTips.isEmpty
                  ? const Center(
                child: Padding(
                  padding: EdgeInsets.all(16.0),
                  child: CircularProgressIndicator(),
                ),
              )
                  : Column(
                children: _financialTips
                    .where((tip) => (tip.contentType ?? 'recommendation') == 'recommendation')
                    .take(3)
                    .map((recommendation) => Padding(
                  padding: const EdgeInsets.symmetric(vertical: 8.0),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('• ',
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            color: Colors.grey[600],
                          )),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              recommendation.title,
                              style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                                color: Colors.grey[700],
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              recommendation.description,
                              style: TextStyle(
                                fontSize: 14,
                                color: Colors.grey[600],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ))
                    .toList(),
              ),

              const SizedBox(height: 32),

              // Dicas Financeiras
              Text(
                'Dicas Financeiras',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: Colors.grey[800],
                ),
              ),
              const SizedBox(height: 8),
              const Divider(thickness: 1.0),
              const SizedBox(height: 8),

              _financialTips.isEmpty
                  ? const Center(
                child: Padding(
                  padding: EdgeInsets.all(16.0),
                  child: CircularProgressIndicator(),
                ),
              )
                  : Column(
                children: _financialTips
                    .where((tip) => (tip.contentType ?? 'tip') == 'tip')
                    .take(3)
                    .map((tip) => _buildTipItem(tip))
                    .toList(),
              ),

              const SizedBox(height: 32),

              // Conteúdo Educacional
              Text(
                'Conteúdo Educacional',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: Colors.grey[800],
                ),
              ),
              const SizedBox(height: 8),
              const Divider(thickness: 1.0),
              const SizedBox(height: 8),

              _educationalContent.isEmpty
                  ? const Center(
                child: Padding(
                  padding: EdgeInsets.all(16.0),
                  child: CircularProgressIndicator(),
                ),
              )
                  : Column(
                children: _educationalContent.take(4).map((content) {
                  return InkWell(
                    onTap: () async {
                      if (content.type == 'article' && content.id.isNotEmpty) {
                        _showArticleBottomSheet(content.id);
                      } else {
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(content: Text('Abrindo: ${content.title}')),
                        );
                      }
                    },
                    child: _buildEducationalContentItem(content),
                  );
                }).toList(),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTipItem(FinancialTip tip) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            margin: const EdgeInsets.only(top: 2),
            child: Icon(Icons.lightbulb_outline, size: 18, color: Colors.amber[700]),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  tip.title,
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: Colors.grey[700],
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  tip.description,
                  style: TextStyle(fontSize: 14, color: Colors.grey[600]),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildEducationalContentItem(EducationalContentItem content) {
    IconData contentIcon;
    String contentTypeText;

    switch (content.type) {
      case 'article':
        contentIcon = Icons.article_outlined;
        contentTypeText = 'Artigo';
        break;
      case 'video':
        contentIcon = Icons.video_library_outlined;
        contentTypeText = 'Vídeo';
        break;
      case 'podcast':
        contentIcon = Icons.headphones_outlined;
        contentTypeText = 'Podcast';
        break;
      default:
        contentIcon = Icons.school_outlined;
        contentTypeText = 'Conteúdo';
    }

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            margin: const EdgeInsets.only(top: 2),
            child: Icon(contentIcon, size: 18, color: Colors.blue[700]),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                RichText(
                  text: TextSpan(
                    text: '$contentTypeText: ',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: Colors.grey[700],
                    ),
                    children: [
                      TextSpan(
                        text: content.title,
                        style: const TextStyle(fontWeight: FontWeight.normal),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  content.description,
                  style: TextStyle(fontSize: 14, color: Colors.grey[600]),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // Mantém o mesmo layout da bottom sheet, agora pegando dados do backend (ou fallback)
  void _showArticleBottomSheet(String articleId) async {
    try {
      showModalBottomSheet(
        context: context,
        isDismissible: true,
        isScrollControlled: true,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
        ),
        builder: (context) => const SizedBox(
          height: 400,
          child: Center(child: CircularProgressIndicator()),
        ),
      );

      final article = await _service.getArticle(articleId);

      if (!mounted) return;
      Navigator.pop(context); // fecha loading

      showModalBottomSheet(
        context: context,
        isDismissible: true,
        isScrollControlled: true,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
        ),
        builder: (context) => DraggableScrollableSheet(
          initialChildSize: 0.85,
          minChildSize: 0.5,
          maxChildSize: 0.95,
          expand: false,
          builder: (context, scrollController) {
            return Container(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(children: [
                    Expanded(
                      child: Text(
                        article.title,
                        style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
                      ),
                    ),
                    IconButton(
                      icon: const Icon(Icons.close),
                      onPressed: () => Navigator.pop(context),
                    ),
                  ]),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      Text('Por ${article.author}',
                          style: TextStyle(fontSize: 14, color: Colors.grey[600])),
                      const SizedBox(width: 12),
                      Icon(Icons.access_time, size: 14, color: Colors.grey[600]),
                      const SizedBox(width: 4),
                      Text('${article.readTimeMinutes} min leitura',
                          style: TextStyle(fontSize: 14, color: Colors.grey[600])),
                    ],
                  ),
                  const Divider(height: 24),
                  Expanded(
                    child: ListView(
                      controller: scrollController,
                      children: [
                        Text(article.content,
                            style: const TextStyle(fontSize: 16, height: 1.6)),
                        const SizedBox(height: 24),
                        Wrap(
                          spacing: 8,
                          runSpacing: 8,
                          children: article.tags
                              .map((tag) => Chip(
                            label: Text('#$tag'),
                            backgroundColor: Colors.grey[200],
                            padding: EdgeInsets.zero,
                          ))
                              .toList(),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            );
          },
        ),
      );
    } catch (e) {
      if (!mounted) return;
      Navigator.pop(context); // fecha loading se aberto
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Erro ao carregar o artigo: $e')),
      );
    }
  }
}
