import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:auren/features/auth/domain/models/transaction.dart';

class AddTransactionScreen extends StatefulWidget {
  final Function(Transaction) onTransactionAdded;

  const AddTransactionScreen({
    super.key,
    required this.onTransactionAdded,
  });

  @override
  State<AddTransactionScreen> createState() => _AddTransactionScreenState();
}

class _AddTransactionScreenState extends State<AddTransactionScreen> {
  final _formKey = GlobalKey<FormState>();

  // Controllers
  final TextEditingController _amountController = TextEditingController();
  final TextEditingController _descriptionController = TextEditingController();

  // Tipo (enum no seu modelo) — começa em Despesa
  TransactionType _type = TransactionType.expense;

  // Categoria (só usada quando for Despesa)
  String? _selectedCategory = 'Alimentação';

  // Categorias disponíveis
  final List<String> _categories = const [
    'Alimentação',
    'Transporte',
    'Lazer',
    'Moradia',
    'Outros',
  ];

  @override
  void dispose() {
    _amountController.dispose();
    _descriptionController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final primaryColor = Theme.of(context).primaryColor;

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: primaryColor,
        title: const Text('Auren', style: TextStyle(color: Colors.white)),
        elevation: 0,
      ),
      body: Form(
        key: _formKey,
        child: Padding(
          padding: const EdgeInsets.all(24.0), // <-- corrigido
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Center(
                child: Text(
                  'Auren',
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.w500,
                    color: Colors.grey,
                  ),
                ),
              ),
              const SizedBox(height: 32),

              // Valor
              TextFormField(
                controller: _amountController,
                decoration: const InputDecoration(
                  labelText: 'Valor',
                  border: UnderlineInputBorder(),
                ),
                keyboardType:
                const TextInputType.numberWithOptions(decimal: true),
                inputFormatters: [
                  FilteringTextInputFormatter.allow(
                    RegExp(r'^\d+\.?\d{0,2}'),
                  ),
                ],
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Por favor informe um valor';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 16),

              // Descrição
              TextFormField(
                controller: _descriptionController,
                decoration: const InputDecoration(
                  labelText: 'Descrição',
                  border: UnderlineInputBorder(),
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Por favor informe uma descrição';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 16),

              // Tipo
              DropdownButtonFormField<TransactionType>(
                value: _type,
                decoration: const InputDecoration(
                  labelText: 'Tipo',
                  border: UnderlineInputBorder(),
                ),
                items: const [
                  DropdownMenuItem(
                    value: TransactionType.expense,
                    child: Text('Despesa'),
                  ),
                  DropdownMenuItem(
                    value: TransactionType.income,
                    child: Text('Renda'),
                  ),
                ],
                onChanged: (val) {
                  if (val != null) {
                    setState(() => _type = val);
                  }
                },
              ),
              const SizedBox(height: 16),

              // Categoria — só aparece quando for DESPESA
              if (_type == TransactionType.expense)
                DropdownButtonFormField<String>(
                  value: _selectedCategory,
                  decoration: const InputDecoration(
                    labelText: 'Categoria',
                    border: UnderlineInputBorder(),
                  ),
                  items: _categories
                      .map(
                        (c) => DropdownMenuItem<String>(
                      value: c,
                      child: Text(c),
                    ),
                  )
                      .toList(),
                  onChanged: (val) => setState(() => _selectedCategory = val),
                  validator: (value) {
                    if (_type == TransactionType.expense) {
                      if (value == null || value.isEmpty) {
                        return 'Por favor selecione uma categoria';
                      }
                    }
                    return null;
                  },
                ),

              const Spacer(),

              // Botão ADICIONAR — forçando cor do texto branca
              ElevatedButton(
                onPressed: _submitForm,
                style: ElevatedButton.styleFrom(
                  backgroundColor: primaryColor,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                ),
                child: const Text(
                  'ADICIONAR',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w500,
                    color: Colors.white,
                  ),
                ),
              ),
              const SizedBox(height: 16),
            ],
          ),
        ),
      ),
    );
  }

  void _submitForm() {
    if (_formKey.currentState!.validate()) {
      final double amount = double.parse(_amountController.text);

      // Categoria padrão para renda (não é exibida, mas o backend requer a chave)
      final String categoryToSend =
      _type == TransactionType.income ? 'Renda' : (_selectedCategory ?? 'Outros');

      final Transaction transaction = Transaction(
        id: 0, // backend define
        amount: amount,
        description: _descriptionController.text,
        category: categoryToSend,
        date: DateTime.now(),
        type: _type, // enum correto
      );

      widget.onTransactionAdded(transaction);

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Transação adicionada com sucesso')),
      );

      // Reset para o padrão da tela
      _amountController.clear();
      _descriptionController.clear();
      setState(() {
        _type = TransactionType.expense;
        _selectedCategory = 'Alimentação';
      });

      Navigator.pop(context);
    }
  }
}
