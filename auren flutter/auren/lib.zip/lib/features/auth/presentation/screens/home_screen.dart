import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import 'add_transaction_screen.dart';
import 'package:auren/features/auth/domain/models/transaction.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:auren/features/auth/data/repositories/transaction_repository.dart';
import 'package:auren/features/auth/data/datasources/transaction_api_service.dart';
import 'insights_screen.dart';
import 'about_screen.dart';
import 'package:auren/features/finance/presentation/screens/simplified_map_screen.dart';

class MonthlyFinancialData {
  final String month;
  final double income;
  final double expense;
  MonthlyFinancialData({
    required this.month,
    required this.income,
    required this.expense,
  });
}

class CategoryExpenseData {
  final String category;
  final double amount;
  final Color color;
  CategoryExpenseData({
    required this.category,
    required this.amount,
    required this.color,
  });
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _selectedIndex = 0;
  bool _isLoading = true;

  final TransactionApiService _transactionService = TransactionApiService();

  List<MonthlyFinancialData> _monthlyData = [];
  List<CategoryExpenseData> _categoryExpenseData = [];
  List<Transaction> _recentTransactions = [];

  late List<Widget> _screens;

  @override
  void initState() {
    super.initState();
    _screens = [
      // 0 => Home (renderizada abaixo)
      // 1 => Adicionar (via push)
      InsightsScreen(showAppBar: false),        // 2
      const SimplifiedMapScreen(showAppBar: false), // 3
      const AboutScreen(showAppBar: false),     // 4
    ];
    _loadData();
  }

  Future<void> _loadData() async {
    setState(() => _isLoading = true);
    try {
      final txs = await _transactionService.getUserTransactions(limit: 200);

      // ----------- Monta últimos 6 meses -----------
      final now = DateTime.now();
      final months = <DateTime>[];
      for (int i = 5; i >= 0; i--) {
        final d = DateTime(now.year, now.month - i, 1);
        months.add(DateTime(d.year, d.month, 1));
      }

      final incomeByMonth = <String, double>{};
      final expenseByMonth = <String, double>{};
      for (final m in months) {
        final key = '${m.year}-${m.month}';
        incomeByMonth[key] = 0;
        expenseByMonth[key] = 0;
      }

      for (final t in txs) {
        final key = '${t.date.year}-${t.date.month}';
        if (!incomeByMonth.containsKey(key)) continue; // fora da janela de 6 meses
        if (t.isExpense) {
          expenseByMonth[key] = expenseByMonth[key]! + t.amount; // amount já positivo no app
        } else {
          incomeByMonth[key] = incomeByMonth[key]! + t.amount;
        }
      }

      final monthLabels = const ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
      final newMonthly = <MonthlyFinancialData>[];
      for (final m in months) {
        final key = '${m.year}-${m.month}';
        newMonthly.add(MonthlyFinancialData(
          month: monthLabels[m.month - 1],
          income: incomeByMonth[key] ?? 0,
          expense: expenseByMonth[key] ?? 0,
        ));
      }

      // ----------- Monta pizza (somente DESPESAS) -----------
      final expenseByCategory = <String, double>{};
      for (final t in txs.where((e) => e.isExpense)) {
        expenseByCategory[t.category] = (expenseByCategory[t.category] ?? 0) + t.amount;
      }

      final palette = <Color>[
        const Color(0xFF4ECDC4),
        const Color(0xFFFF6B6B),
        const Color(0xFFFFE66D),
        const Color(0xFF1A535C),
        const Color(0xFF66D7D1),
        const Color(0xFFF9CF00),
        const Color(0xFFF19A3E),
        const Color(0xFF445E93),
        const Color(0xFF6B4E71),
      ];
      final newCategories = <CategoryExpenseData>[];
      var idx = 0;
      expenseByCategory.forEach((k, v) {
        newCategories.add(CategoryExpenseData(
          category: k,
          amount: v,
          color: palette[idx % palette.length],
        ));
        idx++;
      });

      setState(() {
        _recentTransactions = txs.take(10).toList();
        _monthlyData = newMonthly;
        _categoryExpenseData = newCategories;
        _isLoading = false;
      });
    } catch (e) {
      setState(() => _isLoading = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Erro ao carregar dados: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final primaryColor = Theme.of(context).primaryColor;

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: primaryColor,
        title: const Text('Auren', style: TextStyle(color: Colors.white)),
        elevation: 0,
      ),
      body: _selectedIndex == 0
          ? _buildHomeContent()
          : _screens[_selectedIndex - 2],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        selectedItemColor: primaryColor,
        unselectedItemColor: Colors.grey,
        showSelectedLabels: true,
        showUnselectedLabels: true,
        type: BottomNavigationBarType.fixed,
        onTap: (index) {
          if (index == 0) {
            setState(() => _selectedIndex = 0);
          } else if (index == 1) {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => AddTransactionScreen(
                  onTransactionAdded: _addTransaction,
                ),
              ),
            );
          } else if (index >= 2 && index <= 4) {
            setState(() => _selectedIndex = index);
          }
        },
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
          BottomNavigationBarItem(icon: Icon(Icons.add), label: 'Adicionar'),
          BottomNavigationBarItem(icon: Icon(Icons.show_chart), label: 'Insights'),
          BottomNavigationBarItem(icon: Icon(Icons.map), label: 'Mapa'),
          BottomNavigationBarItem(icon: Icon(Icons.info), label: 'Creditos'),
        ],
      ),
    );
  }

  Widget _buildHomeContent() {
    final primaryColor = Theme.of(context).primaryColor;

    if (_isLoading) {
      return const Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircularProgressIndicator(),
            SizedBox(height: 16),
            Text('Carregando suas informações financeiras...'),
          ],
        ),
      );
    }

    return RefreshIndicator(
      onRefresh: _loadData,
      child: SingleChildScrollView(
        physics: const AlwaysScrollableScrollPhysics(),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 24),
            const SizedBox(height: 24),

            // Visão Mensal (barras)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Text(
                    'Visão Mensal',
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.w500,
                      color: Colors.grey[800],
                    ),
                  ),
                  const SizedBox(height: 16),
                  SizedBox(
                    height: 200,
                    child: _monthlyData.isEmpty
                        ? Center(
                      child: Text(
                        'Sem dados para os últimos meses',
                        style: TextStyle(color: Colors.grey[600]),
                      ),
                    )
                        : _buildMonthlyBarChart(primaryColor),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 32),

            // Categorias de Despesas (pizza)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Text(
                    'Categorias de Despesas',
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.w500,
                      color: Colors.grey[800],
                    ),
                  ),
                  const SizedBox(height: 24),
                  _categoryExpenseData.isEmpty
                      ? Center(
                    child: Text(
                      'Sem despesas categorizadas',
                      style: TextStyle(color: Colors.grey[600]),
                    ),
                  )
                      : _buildCategoryPieChart(),
                ],
              ),
            ),
            const SizedBox(height: 32),

            // Transações Recentes
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'Transações Recentes',
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.w500,
                          color: Colors.grey[800],
                        ),
                      ),
                      IconButton(
                        icon: Icon(Icons.refresh, color: primaryColor),
                        onPressed: _loadData,
                        tooltip: 'Atualizar transações',
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  _recentTransactions.isEmpty
                      ? Center(
                    child: Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: Column(
                        children: [
                          const Icon(Icons.receipt_long, size: 48, color: Colors.grey),
                          const SizedBox(height: 16),
                          Text('Nenhuma transação recente',
                              style: TextStyle(color: Colors.grey[600])),
                        ],
                      ),
                    ),
                  )
                      : ListView.builder(
                    key: ValueKey('transactions_${_recentTransactions.length}'),
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    itemCount: _recentTransactions.length,
                    itemBuilder: (context, i) => _buildTransactionItem(_recentTransactions[i]),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),
          ],
        ),
      ),
    );
  }

  Widget _buildMonthlyBarChart(Color primaryColor) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 8.0),
      child: BarChart(
        BarChartData(
          alignment: BarChartAlignment.spaceAround,
          maxY: _getMaxValue() * 1.2,
          minY: 0,
          barTouchData: BarTouchData(
            enabled: true,
            touchTooltipData: BarTouchTooltipData(
              tooltipPadding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              tooltipBorderRadius: BorderRadius.circular(8),
              tooltipMargin: 8,
              getTooltipItem: (group, groupIndex, rod, rodIndex) {
                final data = _monthlyData[group.x.toInt()];
                return BarTooltipItem(
                  rodIndex == 0
                      ? 'Income: R\$${data.income.toStringAsFixed(2)}'
                      : 'Expense: R\$${data.expense.toStringAsFixed(2)}',
                  const TextStyle(color: Colors.black, fontWeight: FontWeight.bold),
                );
              },
            ),
          ),
          titlesData: FlTitlesData(
            show: true,
            bottomTitles: AxisTitles(
              sideTitles: SideTitles(
                showTitles: true,
                reservedSize: 32,
                getTitlesWidget: (double value, TitleMeta meta) {
                  final idx = value.toInt();
                  if (idx < 0 || idx >= _monthlyData.length) return const SizedBox.shrink();
                  return Padding(
                    padding: const EdgeInsets.only(top: 10.0),
                    child: Text(
                      _monthlyData[idx].month,
                      style: TextStyle(
                        color: Colors.grey[800],
                        fontWeight: FontWeight.bold,
                        fontSize: 12,
                      ),
                    ),
                  );
                },
              ),
            ),
            leftTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
            topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
            rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
          ),
          gridData: const FlGridData(show: false),
          borderData: FlBorderData(show: false),
          barGroups: _getBarGroups(primaryColor),
        ),
      ),
    );
  }

  double _getMaxValue() {
    if (_monthlyData.isEmpty) return 1;
    double max = 0;
    for (var d in _monthlyData) {
      if (d.income > max) max = d.income;
      if (d.expense > max) max = d.expense;
    }
    return max == 0 ? 1 : max;
  }

  List<BarChartGroupData> _getBarGroups(Color primaryColor) {
    final groups = <BarChartGroupData>[];
    for (int i = 0; i < _monthlyData.length; i++) {
      groups.add(
        BarChartGroupData(
          x: i,
          groupVertically: true,
          barRods: [
            BarChartRodData(
              toY: _monthlyData[i].income,
              color: primaryColor,
              width: 12,
              borderRadius: const BorderRadius.only(
                topLeft: Radius.circular(4),
                topRight: Radius.circular(4),
              ),
            ),
            BarChartRodData(
              toY: _monthlyData[i].expense,
              color: primaryColor.withOpacity(0.5),
              width: 12,
              borderRadius: const BorderRadius.only(
                topLeft: Radius.circular(4),
                topRight: Radius.circular(4),
              ),
            ),
          ],
        ),
      );
    }
    return groups;
  }

  Widget _buildCategoryPieChart() {
    final total = _categoryExpenseData.fold<double>(0, (s, e) => s + e.amount);
    if (total <= 0) {
      return Center(
        child: Text('Sem despesas categorizadas', style: TextStyle(color: Colors.grey[600])),
      );
    }

    return Container(
      height: 240,
      padding: const EdgeInsets.only(left: 8.0, right: 8.0, bottom: 8.0),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          // Gráfico
          Expanded(
            flex: 4,
            child: Padding(
              padding: const EdgeInsets.all(4.0),
              child: PieChart(
                PieChartData(
                  sectionsSpace: 2,
                  centerSpaceRadius: 30,
                  sections: _categoryExpenseData.map((d) {
                    final pct = (d.amount / total) * 100;
                    return PieChartSectionData(
                      color: d.color,
                      value: d.amount,
                      title: '${pct.toStringAsFixed(0)}%',
                      radius: 55,
                      titleStyle: const TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                      badgePositionPercentageOffset: 0.98,
                    );
                  }).toList(),
                ),
              ),
            ),
          ),
          // Legenda
          Expanded(
            flex: 4,
            child: Padding(
              padding: const EdgeInsets.only(left: 8.0, right: 8.0),
              child: _categoryExpenseData.length > 5
                  ? ListView.builder(
                shrinkWrap: true,
                physics: const BouncingScrollPhysics(),
                padding: EdgeInsets.zero,
                itemCount: _categoryExpenseData.length,
                itemBuilder: (context, i) => _buildLegendItem(_categoryExpenseData[i]),
              )
                  : Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: _categoryExpenseData.map(_buildLegendItem).toList(),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLegendItem(CategoryExpenseData d) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2.0),
      child: Row(
        children: [
          Container(width: 12, height: 12, decoration: BoxDecoration(color: d.color, shape: BoxShape.circle)),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(d.category,
                    style: TextStyle(fontSize: 11, fontWeight: FontWeight.w500, color: Colors.grey[800]),
                    overflow: TextOverflow.ellipsis),
                Text('R\$ ${d.amount.toStringAsFixed(0)}',
                    style: TextStyle(fontSize: 10, color: Colors.grey[600])),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTransactionItem(Transaction t) {
    final dateStr = '${t.date.day}/${t.date.month}/${t.date.year}';
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 12),
      decoration: BoxDecoration(
        border: Border(bottom: BorderSide(color: Colors.grey[300]!, width: 1)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // texto
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(t.category,
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.w500, color: Colors.grey[800])),
                const SizedBox(height: 4),
                Text(t.description, style: TextStyle(fontSize: 14, color: Colors.grey[600])),
                const SizedBox(height: 4),
                Text(dateStr, style: TextStyle(fontSize: 12, color: Colors.grey[500])),
              ],
            ),
          ),
          // valor
          Text(
            'R\$ ${t.amount.toStringAsFixed(2)}',
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w500,
              color: t.isExpense ? Colors.red : Colors.green,
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _addTransaction(Transaction tx) async {
    setState(() => _isLoading = true);
    try {
      final ok = await _transactionService.submitTransaction(tx);
      if (!ok) throw Exception('Erro ao salvar');

      // Atualiza lista local rapidamente
      setState(() {
        _recentTransactions.insert(0, tx);
        if (_recentTransactions.length > 10) _recentTransactions.removeLast();
        _isLoading = false;
      });

      // Recalcula dados a partir da API para garantir coerência
      await _loadData();

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Transação adicionada com sucesso!')),
      );
    } catch (e) {
      setState(() => _isLoading = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Erro ao adicionar transação: $e')),
      );
    }
  }
}
