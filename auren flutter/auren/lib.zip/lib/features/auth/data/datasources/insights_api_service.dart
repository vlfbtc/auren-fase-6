import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

// MODELS (reaproveitam sua UI existente)
class FinancialTip {
  final String id;
  final String title;
  final String description;
  final String category;
  final String priority;
  final String? contentType; // "tip", "recommendation", etc.
  final String? articleId;

  FinancialTip({
    required this.id,
    required this.title,
    required this.description,
    required this.category,
    required this.priority,
    this.contentType,
    this.articleId,
  });

  factory FinancialTip.fromJson(Map<String, dynamic> json) {
    return FinancialTip(
      id: (json['id'] ?? '').toString(),
      title: json['title'] ?? '',
      description: json['description'] ?? '',
      category: json['category'] ?? '',
      priority: json['priority'] ?? 'low',
      contentType: json['contentType'],
      articleId: json['articleId']?.toString(),
    );
  }
}

class EducationalContentItem {
  final String id;
  final String title;
  final String description;
  final String type; // "article", "video", "podcast"
  final String category;
  final String url;
  final String? thumbnailUrl;
  final String? author;
  final int? readTimeMinutes;
  final List<String> tags;

  EducationalContentItem({
    required this.id,
    required this.title,
    required this.description,
    required this.type,
    required this.category,
    required this.url,
    this.thumbnailUrl,
    this.author,
    this.readTimeMinutes,
    this.tags = const [],
  });

  factory EducationalContentItem.fromJson(Map<String, dynamic> json) {
    return EducationalContentItem(
      id: (json['id'] ?? '').toString(),
      title: json['title'] ?? '',
      description: json['description'] ?? '',
      type: json['type'] ?? 'article',
      category: json['category'] ?? '',
      url: json['url'] ?? '',
      thumbnailUrl: json['thumbnailUrl'],
      author: json['author'],
      readTimeMinutes: json['readTimeMinutes'] is int
          ? json['readTimeMinutes'] as int
          : int.tryParse('${json['readTimeMinutes'] ?? ''}'),
      tags: (json['tags'] is List)
          ? (json['tags'] as List).map((e) => e.toString()).toList()
          : const [],
    );
  }
}

class FinancialArticle {
  final String id;
  final String title;
  final String author;
  final DateTime publishDate;
  final String content;
  final String category;
  final int readTimeMinutes;
  final List<String> tags;

  FinancialArticle({
    required this.id,
    required this.title,
    required this.author,
    required this.publishDate,
    required this.content,
    required this.category,
    required this.readTimeMinutes,
    required this.tags,
  });

  factory FinancialArticle.fromJson(Map<String, dynamic> json) {
    return FinancialArticle(
      id: (json['id'] ?? '').toString(),
      title: json['title'] ?? '',
      author: json['author'] ?? '',
      publishDate: DateTime.tryParse(json['publishDate'] ?? '') ?? DateTime.now(),
      content: json['content'] ?? '',
      category: json['category'] ?? '',
      readTimeMinutes: json['readTimeMinutes'] is int
          ? json['readTimeMinutes'] as int
          : int.tryParse('${json['readTimeMinutes'] ?? ''}') ?? 5,
      tags: (json['tags'] is List)
          ? (json['tags'] as List).map((e) => e.toString()).toList()
          : const [],
    );
  }
}

class InsightsBundle {
  final List<FinancialTip> tips;
  final List<EducationalContentItem> content;
  InsightsBundle({required this.tips, required this.content});
}

/// Resolve a base URL (igual usamos no restante do app)
const String _kDefaultBase = 'http://10.0.2.2:8080/api/v1';
String _apiBase() =>
    const String.fromEnvironment('API_BASE', defaultValue: _kDefaultBase);

class InsightsApiService {
  Future<int> _userId() async {
    final prefs = await SharedPreferences.getInstance();
    final id = prefs.getInt('userId');
    if (id == null) throw Exception('Sessão inválida: userId não encontrado');
    return id;
  }

  Future<String?> _accessToken() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('accessToken');
  }

  Map<String, String> _headers(String? token) => {
    'Content-Type': 'application/json',
    if (token != null) 'Authorization': 'Bearer $token',
  };

  /// Chama o POST /api/v1/users/{userId}/insights para gerar/atualizar insights
  Future<InsightsBundle> generate({int topN = 10}) async {
    final uid = await _userId();
    final token = await _accessToken();
    final uri = Uri.parse('${_apiBase()}/users/$uid/insights');

    final body = jsonEncode({
      'topN': topN,
      // Campos opcionais que seu backend pode aceitar:
      // 'monthlyIncome': 0,
      // 'monthlySavings': 0,
    });

    final resp = await http.post(uri, headers: _headers(token), body: body);
    if (resp.statusCode >= 200 && resp.statusCode < 300) {
      final decoded = jsonDecode(resp.body);
      return _parseBundle(decoded);
    } else {
      throw Exception('Erro ao gerar insights (${resp.statusCode}): ${resp.body}');
    }
  }

  /// Chama o GET /api/v1/users/{userId}/insights/recent para ler o último snapshot
  Future<InsightsBundle> recent() async {
    final uid = await _userId();
    final token = await _accessToken();
    final uri = Uri.parse('${_apiBase()}/users/$uid/insights/recent');

    final resp = await http.get(uri, headers: _headers(token));
    if (resp.statusCode >= 200 && resp.statusCode < 300) {
      final decoded = jsonDecode(resp.body);
      return _parseBundle(decoded);
    } else if (resp.statusCode == 404) {
      // Se não houver snapshot, gere um agora
      return generate();
    } else {
      throw Exception('Erro ao obter insights (${resp.statusCode}): ${resp.body}');
    }
  }

  InsightsBundle _parseBundle(dynamic decoded) {
    final tipsJson = (decoded['tips'] as List? ?? const []);
    final contJson = (decoded['content'] as List? ?? const []);

    final tips =
    tipsJson.map((e) => FinancialTip.fromJson(e as Map<String, dynamic>)).toList();
    final content = contJson
        .map((e) => EducationalContentItem.fromJson(e as Map<String, dynamic>))
        .toList();

    return InsightsBundle(tips: tips, content: content);
  }

  /// Opcional: detalhe de artigo. Se o backend não tiver endpoint específico,
  /// montamos um "detalhe" a partir do item da lista recente.
  Future<FinancialArticle> getArticle(String articleId) async {
    // Tenta achar o conteúdo pelo /recent
    final bundle = await recent();
    final item = bundle.content.firstWhere(
          (c) => c.id == articleId,
      orElse: () => bundle.content.first,
    );

    // Monta um artigo com base no item (sem mudar layout da sua bottom sheet)
    return FinancialArticle(
      id: item.id,
      title: item.title,
      author: item.author ?? 'Auren',
      publishDate: DateTime.now(),
      content: item.description.isNotEmpty
          ? item.description
          : 'Conteúdo educacional selecionado para você. Acesse: ${item.url}',
      category: item.category,
      readTimeMinutes: item.readTimeMinutes ?? 5,
      tags: item.tags,
    );
  }
}
