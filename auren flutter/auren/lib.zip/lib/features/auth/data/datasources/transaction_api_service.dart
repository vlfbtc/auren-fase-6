import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:auren/features/auth/domain/models/transaction.dart';

const String _kDefaultBase = 'http://10.0.2.2:8080/api/v1';
String _apiBase() =>
    const String.fromEnvironment('API_BASE', defaultValue: _kDefaultBase);

class TransactionApiService {
  final String baseUrl;
  final http.Client _client;

  TransactionApiService({String? baseUrl, http.Client? client})
      : baseUrl = baseUrl ?? _apiBase(),
        _client = client ?? http.Client();

  Future<Map<String, String>> _headers() async {
    final prefs = await SharedPreferences.getInstance();
    final token = prefs.getString('accessToken') ?? '';
    return {
      'Content-Type': 'application/json',
      if (token.isNotEmpty) 'Authorization': 'Bearer $token',
    };
  }

  Future<int> _userId() async {
    final prefs = await SharedPreferences.getInstance();
    final id = prefs.getInt('userId');
    if (id == null) throw Exception('Sessão inválida: userId não encontrado');
    return id;
  }

  String _yyyyMmDd(DateTime d) =>
      '${d.year.toString().padLeft(4, '0')}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

  /// Busca transações dos últimos 6 meses (mais recentes primeiro).
  Future<List<Transaction>> getUserTransactions({int limit = 10}) async {
    final userId = await _userId();
    final now = DateTime.now();
    final from = DateTime(now.year, now.month - 5, 1);
    final to = now;

    final uri = Uri.parse(
      '$baseUrl/users/$userId/transactions'
          '?from=${_yyyyMmDd(from)}&to=${_yyyyMmDd(to)}&limit=$limit',
    );

    final resp = await _client.get(uri, headers: await _headers());
    if (resp.statusCode != 200) {
      throw Exception('Falha ao carregar transações: ${resp.statusCode} ${resp.body}');
    }

    final list = Transaction.listFromJson(resp.body);
    list.sort((a, b) => b.date.compareTo(a.date));
    return list;
  }

  /// Cria transação. Envia `type` (INCOME/EXPENSE) e data como yyyy-MM-dd.
  Future<bool> submitTransaction(Transaction t) async {
    final userId = await _userId();
    final uri = Uri.parse('$baseUrl/users/$userId/transactions');

    // Começa do toCreateJson() do model e apenas adequa a data + categoria p/ renda
    final map = t.toCreateJson();
    map['date'] = _yyyyMmDd(t.date);
    if (t.type == TransactionType.income) {
      map['category'] = 'Renda'; // renda não é categorizada no app
    }

    final resp = await _client.post(
      uri,
      headers: await _headers(),
      body: json.encode(map),
    );

    return resp.statusCode == 201 || resp.statusCode == 200;
  }
}
