// lib/features/auth/data/repositories/insights_repository.dart
import 'package:shared_preferences/shared_preferences.dart';
import 'package:auren/core/api_client.dart';

class InsightsRepository {
  final ApiClient api;
  InsightsRepository({required this.api});

  Future<int> _userId() async {
    final sp = await SharedPreferences.getInstance();
    final id = sp.getInt('userId');
    if (id == null) throw Exception('userId não encontrado na sessão');
    return id;
  }

  // -------------------------
  // API "oficial" que criamos
  // -------------------------
  Future<dynamic> createInsights({
    List<String>? topCategories,
    double? monthlySavings,
  }) async {
    final uid = await _userId();
    return await api.post('/users/$uid/insights', {
      if (topCategories != null) 'topCategories': topCategories,
      if (monthlySavings != null) 'monthlySavings': monthlySavings,
    });
  }

  Future<dynamic> recentInsights() async {
    final uid = await _userId();
    return await api.get('/users/$uid/insights/recent');
  }

  // ---------------------------------------
  // ALIASES para manter compatibilidade BLoC
  // ---------------------------------------

  /// Alias de `recentInsights()`
  Future<dynamic> recent() => recentInsights();

  /// Alias de `createInsights(...)`
  Future<dynamic> generate({
    List<String>? topCategories,
    double? monthlySavings,
  }) =>
      createInsights(topCategories: topCategories, monthlySavings: monthlySavings);
}
