import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:auren/core/api_client.dart';

class AuthRepository {
  final ApiClient api;
  AuthRepository({required this.api});

  Future<Map<String, dynamic>> login({
    required String email,
    required String password,
  }) async {
    final res = await api.post('/auth/login', {
      'email': email,
      'password': password,
    });
    final data = res is String ? jsonDecode(res) : (res as Map<String, dynamic>);

    final prefs = await SharedPreferences.getInstance();
    final user = data['user'];
    if (data['accessToken'] != null) {
      await prefs.setString('accessToken', data['accessToken']);
    }
    if (data['refreshToken'] != null) {
      await prefs.setString('refreshToken', data['refreshToken']);
    }
    if (user != null && user['id'] != null) {
      final uid = user['id'] is int ? user['id'] : int.parse(user['id'].toString());
      await prefs.setInt('userId', uid);
    }
    return data;
  }

  Future<Map<String, dynamic>> signupStart({
    required String email,
    required String firstName,
    required String lastName,
    required DateTime birthDate,
  }) async {
    final res = await api.post('/auth/signup', {
      'email': email,
      'firstName': firstName,
      'lastName': lastName,
      'birthDate': birthDate.toIso8601String().split('T').first,
    });
    return res is String ? jsonDecode(res) : (res as Map<String, dynamic>);
  }

  /// Agora retorna o userId que o backend envia
  Future<int> verifyPin({
    required String email,
    required String pin,
  }) async {
    final res = await api.post('/auth/verify-pin', {'email': email, 'pin': pin});
    final data = res is String ? jsonDecode(res) : (res as Map<String, dynamic>);
    final rawId = data['userId'] ?? data['id'] ?? data['user_id'];
    if (rawId == null) {
      throw Exception('userId ausente na resposta de verify-pin');
    }
    return rawId is int ? rawId : int.parse(rawId.toString());
  }

  Future<Map<String, dynamic>> createPassword({
    required int userId,
    required String password,
  }) async {
    final res = await api.post('/auth/create-password', {
      'userId': userId,
      'password': password,
    });
    return res is String ? jsonDecode(res) : (res as Map<String, dynamic>);
  }

  Future<Map<String, dynamic>> refresh({
    required String refreshToken,
  }) async {
    final res = await api.post('/auth/refresh', {'refreshToken': refreshToken});
    return res is String ? jsonDecode(res) : (res as Map<String, dynamic>);
  }

  /// Novo: limpar sessão local
  Future<void> logout() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('accessToken');
    await prefs.remove('refreshToken');
    await prefs.remove('userId');
  }
}
