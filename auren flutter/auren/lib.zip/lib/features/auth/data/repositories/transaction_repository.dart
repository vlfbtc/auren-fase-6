import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:auren/core/api_client.dart';
import 'package:auren/features/auth/domain/models/transaction.dart';

class TransactionRepository {
  final ApiClient api;
  TransactionRepository({required this.api});

  Future<int> _userId() async {
    final prefs = await SharedPreferences.getInstance();
    final id = prefs.getInt('userId');
    if (id == null) throw Exception('Sessão inválida: userId não encontrado');
    return id;
  }

  Future<List<Transaction>> fetchTransactions({int limit = 10}) async {
    final uid = await _userId();
    // ApiClient.get não aceita query nomeado -> concatena na URL
    final res = await api.get('/users/$uid/transactions?limit=$limit');
    final body = res is String ? res : jsonEncode(res);
    return Transaction.listFromJson(body);
  }

  Future<void> addTransaction(Transaction tx) async {
    final uid = await _userId();
    await api.post('/users/$uid/transactions', tx.toCreateJson());
  }

  // Deixei prontos para quando você habilitar no backend
  Future<void> deleteTransaction(int id) async {
    final uid = await _userId();
    await api.delete('/users/$uid/transactions/$id');
  }
}
