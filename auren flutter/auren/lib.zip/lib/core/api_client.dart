// lib/core/api_client.dart
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class ApiClient {
  final String baseUrl;
  ApiClient({required this.baseUrl});

  Future<Map<String, String>> _headers({bool withAuth = true}) async {
    final h = <String, String>{'Content-Type': 'application/json'};
    if (withAuth) {
      final sp = await SharedPreferences.getInstance();
      final token = sp.getString('accessToken');
      if (token == null || token.isEmpty) {
        throw Exception('Sessão expirada. Faça login novamente.');
      }
      h['Authorization'] = 'Bearer $token';
    }
    return h;
  }

  Uri _u(String pathWithLeadingSlash) {
    if (pathWithLeadingSlash.startsWith('/')) {
      return Uri.parse('$baseUrl$pathWithLeadingSlash');
    }
    return Uri.parse('$baseUrl/$pathWithLeadingSlash');
  }

  Future<dynamic> get(String path, {bool auth = true}) async {
    final res = await http.get(_u(path), headers: await _headers(withAuth: auth));
    return _decodeOrThrow(res);
  }

  Future<dynamic> post(String path, Map<String, dynamic> body, {bool auth = true}) async {
    final res = await http.post(_u(path), headers: await _headers(withAuth: auth), body: jsonEncode(body));
    return _decodeOrThrow(res);
  }

  Future<dynamic> put(String path, Map<String, dynamic> body, {bool auth = true}) async {
    final res = await http.put(_u(path), headers: await _headers(withAuth: auth), body: jsonEncode(body));
    return _decodeOrThrow(res);
  }

  Future<void> delete(String path, {bool auth = true}) async {
    final res = await http.delete(_u(path), headers: await _headers(withAuth: auth));
    if (res.statusCode < 200 || res.statusCode >= 300) {
      _throwHttp(res);
    }
  }

  dynamic _decodeOrThrow(http.Response r) {
    if (r.statusCode >= 200 && r.statusCode < 300) {
      if (r.body.isEmpty) return null;
      return jsonDecode(r.body);
    }
    _throwHttp(r);
  }

  Never _throwHttp(http.Response r) {
    try {
      final m = jsonDecode(r.body);
      if (m is Map && m['message'] != null) {
        throw Exception(m['message'].toString());
      }
    } catch (_) {}
    throw Exception('Erro ${r.statusCode} ao comunicar com o servidor.');
  }
}
