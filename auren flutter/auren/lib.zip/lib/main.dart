import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

// Core + repos
import 'core/api_client.dart';
import 'features/auth/data/repositories/auth_repository.dart';
import 'features/auth/data/repositories/transaction_repository.dart';
import 'features/auth/data/repositories/insights_repository.dart';

// BLoCs
import 'package:auren/bloc/auth_bloc.dart';
import 'package:auren/bloc/transaction_bloc.dart';
import 'package:auren/bloc/insights_bloc.dart';

// Telas
import 'features/auth/presentation/screens/login_screen.dart';
import 'features/auth/presentation/screens/signup_screen.dart';
import 'features/auth/presentation/screens/verification_code_screen.dart';
import 'features/auth/presentation/screens/password_creation_screen.dart';
import 'features/auth/presentation/screens/home_screen.dart';

/// Base URL (emulador Android usa 10.0.2.2)
const String kDefaultBase = 'http://10.0.2.2:8080/api/v1';
String get apiBase =>
    const String.fromEnvironment('API_BASE', defaultValue: kDefaultBase);

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const AurenApp());
}

class AurenApp extends StatelessWidget {
  const AurenApp({super.key});

  @override
  Widget build(BuildContext context) {
    final api = ApiClient(baseUrl: apiBase);
    final authRepo = AuthRepository(api: api);
    final txRepo = TransactionRepository(api: api);
    final insRepo = InsightsRepository(api: api);

    return MultiRepositoryProvider(
      providers: [
        RepositoryProvider.value(value: authRepo),
        RepositoryProvider.value(value: txRepo),
        RepositoryProvider.value(value: insRepo),
      ],
      child: MultiBlocProvider(
        providers: [
          BlocProvider(create: (_) => AuthBloc(authRepo: authRepo)),
          BlocProvider(create: (_) => TransactionBloc(txRepo: txRepo)),
          BlocProvider(create: (_) => InsightsBloc(insRepo: insRepo)),
        ],
        child: MaterialApp(
          title: 'Auren',
          debugShowCheckedModeBanner: false,
          theme: ThemeData(
            colorScheme: ColorScheme.fromSeed(seedColor: Colors.teal),
            useMaterial3: true,
          ),
          initialRoute: '/login',
          routes: {
            '/login': (ctx) => const LoginScreen(),
            '/signup': (ctx) => const SignupScreen(),
            // Rotas com leitura segura de arguments (evita cast de null)
            '/verify': (ctx) {
              final args = ModalRoute.of(ctx)!.settings.arguments;
              final Map<String, dynamic> data =
              (args is Map<String, dynamic>) ? args : <String, dynamic>{};
              return VerificationCodeScreen(userData: data);
            },
            '/create-password': (ctx) {
              final args = ModalRoute.of(ctx)!.settings.arguments;
              final Map<String, dynamic> data =
              (args is Map<String, dynamic>) ? args : <String, dynamic>{};
              return PasswordCreationScreen(userData: data);
            },
            '/main': (ctx) => const HomeScreen(),
          },
        ),
      ),
    );
  }
}
