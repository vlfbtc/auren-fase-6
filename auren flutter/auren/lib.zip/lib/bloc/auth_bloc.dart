import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:auren/features/auth/data/repositories/auth_repository.dart';

/// STATES
abstract class AuthState extends Equatable {
  const AuthState();
  @override
  List<Object?> get props => [];
}

class AuthInitial extends AuthState { const AuthInitial(); }
class AuthLoading extends AuthState { const AuthLoading(); }
class AuthAuthenticated extends AuthState { const AuthAuthenticated(); }
class AuthError extends AuthState {
  final String message;
  const AuthError(this.message);
  @override
  List<Object?> get props => [message];
}
class AuthSignupPinSent extends AuthState {
  final String email;
  const AuthSignupPinSent(this.email);
  @override
  List<Object?> get props => [email];
}
class AuthPinVerified extends AuthState {
  final int userId;
  const AuthPinVerified(this.userId);
  @override
  List<Object?> get props => [userId];
}
class AuthPasswordCreated extends AuthState {
  const AuthPasswordCreated();
}

/// EVENTS
abstract class AuthEvent extends Equatable {
  const AuthEvent();
  @override
  List<Object?> get props => [];
}

class LoginRequested extends AuthEvent {
  final String email;
  final String password;
  const LoginRequested({required this.email, required this.password});
  @override
  List<Object?> get props => [email, password];
}

class SignupStartRequested extends AuthEvent {
  final String email;
  final String firstName;
  final String lastName;
  final DateTime birthDate;
  const SignupStartRequested({
    required this.email,
    required this.firstName,
    required this.lastName,
    required this.birthDate,
  });
  @override
  List<Object?> get props => [email, firstName, lastName, birthDate];
}

class VerifyPinRequested extends AuthEvent {
  final String email;
  final String pin;
  const VerifyPinRequested({required this.email, required this.pin});
  @override
  List<Object?> get props => [email, pin];
}

class CreatePasswordRequested extends AuthEvent {
  final int userId;
  final String password;
  const CreatePasswordRequested({required this.userId, required this.password});
  @override
  List<Object?> get props => [userId, password];
}

class LogoutRequested extends AuthEvent {
  const LogoutRequested();
}

class AuthBloc extends Bloc<AuthEvent, AuthState> {
  final AuthRepository authRepo;
  AuthBloc({required this.authRepo}) : super(const AuthInitial()) {
    on<LoginRequested>(_onLogin);
    on<SignupStartRequested>(_onSignupStart);
    on<VerifyPinRequested>(_onVerifyPin);
    on<CreatePasswordRequested>(_onCreatePassword);
    on<LogoutRequested>(_onLogout);
  }

  Future<void> _onLogin(LoginRequested e, Emitter<AuthState> emit) async {
    emit(const AuthLoading());
    try {
      await authRepo.login(email: e.email, password: e.password);
      emit(const AuthAuthenticated());
    } catch (ex) {
      emit(AuthError(ex.toString().replaceFirst('Exception: ', '')));
    }
  }

  Future<void> _onSignupStart(SignupStartRequested e, Emitter<AuthState> emit) async {
    emit(const AuthLoading());
    try {
      await authRepo.signupStart(
        email: e.email,
        firstName: e.firstName,
        lastName: e.lastName,
        birthDate: e.birthDate,
      );
      emit(AuthSignupPinSent(e.email));
    } catch (ex) {
      emit(AuthError(ex.toString().replaceFirst('Exception: ', '')));
    }
  }

  Future<void> _onVerifyPin(VerifyPinRequested e, Emitter<AuthState> emit) async {
    emit(const AuthLoading());
    try {
      final userId = await authRepo.verifyPin(email: e.email, pin: e.pin);
      emit(AuthPinVerified(userId));
    } catch (ex) {
      emit(AuthError(ex.toString().replaceFirst('Exception: ', '')));
    }
  }

  Future<void> _onCreatePassword(CreatePasswordRequested e, Emitter<AuthState> emit) async {
    emit(const AuthLoading());
    try {
      await authRepo.createPassword(userId: e.userId, password: e.password);
      // Não forçamos login automático; deixamos a UI voltar para Login
      emit(const AuthPasswordCreated());
    } catch (ex) {
      emit(AuthError(ex.toString().replaceFirst('Exception: ', '')));
    }
  }

  Future<void> _onLogout(LogoutRequested e, Emitter<AuthState> emit) async {
    await authRepo.logout();
    emit(const AuthInitial());
  }
}
