import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:auren/features/auth/data/models/insights_models.dart';
import 'package:auren/features/auth/data/repositories/insights_repository.dart';

/// EVENTS
abstract class InsightsEvent extends Equatable {
  const InsightsEvent();
  @override
  List<Object?> get props => [];
}

class LoadInsights extends InsightsEvent {
  const LoadInsights();
}

class GenerateInsights extends InsightsEvent {
  final List<String>? topCategories;
  final double? monthlySavings;
  const GenerateInsights({this.topCategories, this.monthlySavings});
  @override
  List<Object?> get props => [topCategories, monthlySavings];
}

/// STATES
abstract class InsightsState extends Equatable {
  const InsightsState();
  @override
  List<Object?> get props => [];
}

class InsightsInitial extends InsightsState {
  const InsightsInitial();
}

class InsightsLoading extends InsightsState {
  const InsightsLoading();
}

class InsightsLoaded extends InsightsState {
  final List<InsightItem> items;
  const InsightsLoaded(this.items);
  @override
  List<Object?> get props => [items];
}

class InsightsError extends InsightsState {
  final String message;
  const InsightsError(this.message);
  @override
  List<Object?> get props => [message];
}

/// BLoC
class InsightsBloc extends Bloc<InsightsEvent, InsightsState> {
  final InsightsRepository insRepo;
  InsightsBloc({required this.insRepo}) : super(const InsightsInitial()) {
    on<LoadInsights>(_onLoad);
    on<GenerateInsights>(_onGenerate);
  }

  Future<void> _onLoad(LoadInsights e, Emitter<InsightsState> emit) async {
    emit(const InsightsLoading());
    try {
      final list = await insRepo.recent();
      emit(InsightsLoaded(list));
    } catch (ex) {
      emit(InsightsError(ex.toString().replaceFirst('Exception: ', '')));
    }
  }

  Future<void> _onGenerate(GenerateInsights e, Emitter<InsightsState> emit) async {
    emit(const InsightsLoading());
    try {
      await insRepo.generate(topCategories: e.topCategories, monthlySavings: e.monthlySavings);
      final list = await insRepo.recent();
      emit(InsightsLoaded(list));
    } catch (ex) {
      emit(InsightsError(ex.toString().replaceFirst('Exception: ', '')));
    }
  }
}
